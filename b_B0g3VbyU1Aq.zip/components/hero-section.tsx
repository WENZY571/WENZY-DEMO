"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Play, Info, Star, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import type { Movie } from "@/lib/movies"

interface HeroSectionProps {
  movies: Movie[]
}

export function HeroSection({ movies }: HeroSectionProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const currentMovie = movies[currentIndex]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % movies.length)
    }, 8000)
    return () => clearInterval(interval)
  }, [movies.length])

  return (
    <section id="bosh-sahifa" className="relative h-[85vh] min-h-[600px] overflow-hidden">
      {/* Background Images */}
      {movies.map((movie, index) => (
        <div
          key={movie.id}
          className={cn(
            "absolute inset-0 transition-opacity duration-1000",
            index === currentIndex ? "opacity-100" : "opacity-0"
          )}
        >
          <Image
            src={movie.image}
            alt={movie.title}
            fill
            className="object-cover"
            priority={index === 0}
            sizes="100vw"
          />
        </div>
      ))}

      {/* Gradient Overlays */}
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/60 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />

      {/* Content */}
      <div className="absolute inset-0 flex items-center">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl">
            {/* Movie Badge */}
            <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full mb-6">
              <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
              <span className="text-sm font-medium text-foreground">Trenddagi kino</span>
            </div>

            {/* Title */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-4 text-balance">
              {currentMovie.title}
            </h1>

            {/* Meta Info */}
            <div className="flex flex-wrap items-center gap-4 mb-6 text-muted-foreground">
              <span className="flex items-center gap-1">
                <Star className="h-5 w-5 fill-yellow-500 text-yellow-500" />
                <span className="font-semibold text-foreground">{currentMovie.rating}</span>
              </span>
              <span>{currentMovie.year}</span>
              <span className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {currentMovie.duration}
              </span>
              <span className="px-2 py-1 bg-primary/20 text-primary rounded text-sm">
                {currentMovie.genre}
              </span>
            </div>

            {/* Description */}
            <p className="text-lg text-muted-foreground mb-8 line-clamp-3 text-pretty">
              {currentMovie.description}
            </p>

            {/* Buttons */}
            <div className="flex flex-wrap items-center gap-4">
              <Link href={`/movie/${currentMovie.id}`}>
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  <Play className="h-5 w-5 mr-2 fill-current" />
                  Hozir ko&apos;rish
                </Button>
              </Link>
              <Link href={`/movie/${currentMovie.id}`}>
                <Button size="lg" variant="secondary" className="glass">
                  <Info className="h-5 w-5 mr-2" />
                  Batafsil
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-2">
        {movies.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={cn(
              "h-1 rounded-full transition-all duration-300",
              index === currentIndex
                ? "w-8 bg-primary"
                : "w-4 bg-muted-foreground/50 hover:bg-muted-foreground"
            )}
            aria-label={`Slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  )
}
