"use client"

import Image from "next/image"
import Link from "next/link"
import { Play, Star, Clock, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import type { Movie } from "@/lib/movies"

interface MovieCardProps {
  movie: Movie
  variant?: "default" | "large"
}

export function MovieCard({ movie, variant = "default" }: MovieCardProps) {
  const isLarge = variant === "large"

  return (
    <Link href={`/movie/${movie.id}`} className="block">
      <div
        className={cn(
          "group relative rounded-lg overflow-hidden transition-all duration-300",
          "hover:scale-105 hover:z-10 hover:shadow-2xl hover:shadow-primary/20",
          isLarge ? "aspect-[16/9]" : "aspect-[2/3]"
        )}
      >
        {/* Movie Poster */}
        <Image
          src={movie.image}
          alt={movie.title}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-110"
          sizes={isLarge ? "(max-width: 768px) 100vw, 50vw" : "(max-width: 768px) 50vw, 20vw"}
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Rating Badge */}
        <div className="absolute top-2 right-2 glass px-2 py-1 rounded-md flex items-center gap-1">
          <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
          <span className="text-xs font-semibold text-foreground">{movie.rating}</span>
        </div>

        {/* Hover Content */}
        <div className="absolute inset-0 p-4 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-4 group-hover:translate-y-0">
          <h3 className="font-bold text-lg text-foreground mb-1 line-clamp-2">{movie.title}</h3>
          
          <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2">
            <span>{movie.year}</span>
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {movie.duration}
            </span>
            <span className="text-primary">{movie.genre}</span>
          </div>

          {isLarge && (
            <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{movie.description}</p>
          )}

          <div className="flex items-center gap-2">
            <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Play className="h-4 w-4 mr-1 fill-current" />
              Ko&apos;rish
            </Button>
            <Button size="sm" variant="secondary" className="glass">
              <Info className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </Link>
  )
}
