"use client"

import Link from "next/link"
import { Send, Instagram, MessageCircle, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export function ContactSection() {
  return (
    <section id="boglanish" className="py-20 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/50 to-background" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Biz bilan bog&apos;laning
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Savollaringiz bormi? Biz bilan ijtimoiy tarmoqlar orqali bog&apos;laning yoki xabar qoldiring.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {/* Contact Form */}
          <div className="glass rounded-2xl p-8">
            <h3 className="text-xl font-semibold text-foreground mb-6">Xabar yuborish</h3>
            <form className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="text-sm text-muted-foreground mb-2 block">
                    Ismingiz
                  </label>
                  <Input
                    id="name"
                    placeholder="Ismingizni kiriting"
                    className="bg-secondary border-border"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="text-sm text-muted-foreground mb-2 block">
                    Email
                  </label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="email@example.com"
                    className="bg-secondary border-border"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="subject" className="text-sm text-muted-foreground mb-2 block">
                  Mavzu
                </label>
                <Input
                  id="subject"
                  placeholder="Xabar mavzusi"
                  className="bg-secondary border-border"
                />
              </div>
              <div>
                <label htmlFor="message" className="text-sm text-muted-foreground mb-2 block">
                  Xabar
                </label>
                <Textarea
                  id="message"
                  placeholder="Xabaringizni yozing..."
                  className="bg-secondary border-border min-h-[120px]"
                />
              </div>
              <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                Yuborish
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </form>
          </div>

          {/* Social Links */}
          <div className="flex flex-col justify-center">
            <h3 className="text-xl font-semibold text-foreground mb-6">
              Ijtimoiy tarmoqlarda kuzating
            </h3>
            <p className="text-muted-foreground mb-8">
              So&apos;nggi yangiliklar, yangi kinolar va maxsus takliflar haqida birinchi bo&apos;lib xabardor bo&apos;ling.
            </p>

            <div className="space-y-4">
              {/* Telegram */}
              <Link
                href="https://t.me/WENZY_VIP7"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 glass rounded-xl p-4 hover:bg-primary/10 transition-all group"
              >
                <div className="w-14 h-14 rounded-full bg-[#0088cc]/20 flex items-center justify-center">
                  <Send className="h-6 w-6 text-[#0088cc]" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                    Telegram
                  </h4>
                  <p className="text-sm text-muted-foreground">@WENZY_VIP7</p>
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
              </Link>

              {/* Instagram */}
              <Link
                href="https://instagram.com/WENZY_VIP7"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 glass rounded-xl p-4 hover:bg-primary/10 transition-all group"
              >
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#f09433] via-[#e6683c] to-[#bc1888] flex items-center justify-center">
                  <Instagram className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                    Instagram
                  </h4>
                  <p className="text-sm text-muted-foreground">@WENZY_VIP7</p>
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
              </Link>

              {/* Support */}
              <div className="flex items-center gap-4 glass rounded-xl p-4">
                <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center">
                  <MessageCircle className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-foreground">24/7 Qo&apos;llab-quvvatlash</h4>
                  <p className="text-sm text-muted-foreground">Har doim yordam berishga tayyormiz</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
