import Link from "next/link"
import { Play, Send, Instagram, Mail, Phone, MapPin } from "lucide-react"

const footerLinks = {
  platform: [
    { label: "Bosh sahifa", href: "#bosh-sahifa" },
    { label: "Jangari filmlar", href: "#jangari" },
    { label: "Komediya", href: "#komediya" },
    { label: "Qo'rqinchli", href: "#qorqinchli" },
  ],
  support: [
    { label: "Yordam markazi", href: "#" },
    { label: "FAQ", href: "#" },
    { label: "Maxfiylik siyosati", href: "#" },
    { label: "Foydalanish shartlari", href: "#" },
  ],
  contact: [
    { label: "Biz bilan bog'lanish", href: "#boglanish" },
    { label: "Hamkorlik", href: "#" },
    { label: "Reklama", href: "#" },
  ],
}

export function Footer() {
  return (
    <footer className="bg-card border-t border-border">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <Play className="h-8 w-8 fill-primary text-primary" />
              <span className="text-2xl font-bold text-primary">KinoFlix</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              O&apos;zbekistondagi eng yaxshi onlayn kino platformasi. Minglab filmlar va seriallarni tomosha qiling.
            </p>
            <div className="flex items-center gap-4">
              <Link
                href="https://t.me/WENZY_VIP7"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 glass rounded-full flex items-center justify-center hover:bg-primary/20 transition-colors"
                aria-label="Telegram"
              >
                <Send className="h-5 w-5 text-foreground" />
              </Link>
              <Link
                href="https://instagram.com/WENZY_VIP7"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 glass rounded-full flex items-center justify-center hover:bg-primary/20 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5 text-foreground" />
              </Link>
            </div>
          </div>

          {/* Platform Links */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">Platforma</h3>
            <ul className="space-y-3">
              {footerLinks.platform.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">Qo&apos;llab-quvvatlash</h3>
            <ul className="space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">Aloqa</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Mail className="h-4 w-4 text-primary" />
                info@kinoflix.uz
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4 text-primary" />
                +998 90 123 45 67
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 text-primary" />
                Toshkent, O&apos;zbekiston
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} KinoFlix. Barcha huquqlar himoyalangan.
          </p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link href="#" className="hover:text-primary transition-colors">
              Maxfiylik
            </Link>
            <Link href="#" className="hover:text-primary transition-colors">
              Shartlar
            </Link>
            <Link href="#" className="hover:text-primary transition-colors">
              Cookie
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
