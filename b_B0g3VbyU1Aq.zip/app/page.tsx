import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { MovieSection } from "@/components/movie-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"
import {
  trendingMovies,
  actionMovies,
  comedyMovies,
  horrorMovies,
} from "@/lib/movies"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <HeroSection movies={trendingMovies} />
      
      <div className="relative z-10 -mt-20">
        <MovieSection
          title="Trenddagi Kinolar"
          movies={trendingMovies}
        />
        
        <MovieSection
          id="jangari"
          title="Jangari Filmlar"
          movies={actionMovies}
        />
        
        <MovieSection
          id="komediya"
          title="Komediya"
          movies={comedyMovies}
        />
        
        <MovieSection
          id="qorqinchli"
          title="Qo'rqinchli Kinolar"
          movies={horrorMovies}
        />
      </div>

      <ContactSection />
      <Footer />
    </main>
  )
}
