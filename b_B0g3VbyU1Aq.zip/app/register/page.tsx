"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Play, Eye, EyeOff, ArrowLeft, Check, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"

const features = [
  "Minglab filmlar va seriallar",
  "HD va 4K sifat",
  "Reklama tashvishlarsiz",
  "Cheksiz tomosha qilish",
]

export default function RegisterPage() {
  const router = useRouter()
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
    terms: false,
  })
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validateForm = () => {
    const newErrors: Record<string, string> = {}
    
    if (!formData.firstName.trim()) {
      newErrors.firstName = "Ism kiritish shart"
    }
    
    if (!formData.lastName.trim()) {
      newErrors.lastName = "Familiya kiritish shart"
    }
    
    if (!formData.email.trim()) {
      newErrors.email = "Email kiritish shart"
    } else if (!formData.email.includes("@") || !formData.email.includes(".")) {
      newErrors.email = "To'g'ri email manzil kiriting"
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = "Telefon raqam kiritish shart"
    } else if (!/^\+?[\d\s-]{9,}$/.test(formData.phone.replace(/\s/g, ""))) {
      newErrors.phone = "To'g'ri telefon raqam kiriting"
    }
    
    if (!formData.password) {
      newErrors.password = "Parol kiritish shart"
    } else if (formData.password.length < 8) {
      newErrors.password = "Parol kamida 8 ta belgidan iborat bo'lishi kerak"
    }
    
    if (!formData.terms) {
      newErrors.terms = "Shartlarni qabul qilish shart"
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!validateForm()) return
    
    setIsLoading(true)
    
    // Simulate registration (frontend demo only)
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Store user data in localStorage for demo
    localStorage.setItem("kinoflix_user", JSON.stringify({
      firstName: formData.firstName,
      lastName: formData.lastName,
      email: formData.email,
      phone: formData.phone,
      loggedIn: true,
    }))
    
    setIsLoading(false)
    router.push("/")
  }

  return (
    <div className="min-h-screen flex relative overflow-hidden">
      {/* Left Side - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 relative z-10">
        {/* Mobile Background */}
        <div className="absolute inset-0 lg:hidden bg-[url('https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1920&h=1080&fit=crop')] bg-cover bg-center" />
        <div className="absolute inset-0 lg:hidden bg-background/90 backdrop-blur-sm" />

        {/* Back Button */}
        <Link
          href="/"
          className="absolute top-6 left-6 flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          Orqaga
        </Link>

        <div className="relative w-full max-w-md">
          <div className="glass rounded-2xl p-8 sm:p-10">
            {/* Logo */}
            <div className="flex items-center justify-center gap-2 mb-8">
              <Play className="h-10 w-10 fill-primary text-primary" />
              <span className="text-3xl font-bold text-primary">KinoFlix</span>
            </div>

            <h1 className="text-2xl font-bold text-foreground text-center mb-2">
              Hisob yarating
            </h1>
            <p className="text-muted-foreground text-center mb-8">
              Bepul ro&apos;yxatdan o&apos;ting va kinolar olamiga kirsin
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="firstName" className="text-sm text-muted-foreground mb-2 block">
                    Ism
                  </label>
                  <Input
                    id="firstName"
                    placeholder="Ismingiz"
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className={`bg-secondary border-border h-12 ${errors.firstName ? "border-red-500" : ""}`}
                  />
                  {errors.firstName && (
                    <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>
                  )}
                </div>
                <div>
                  <label htmlFor="lastName" className="text-sm text-muted-foreground mb-2 block">
                    Familiya
                  </label>
                  <Input
                    id="lastName"
                    placeholder="Familiyangiz"
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className={`bg-secondary border-border h-12 ${errors.lastName ? "border-red-500" : ""}`}
                  />
                  {errors.lastName && (
                    <p className="text-red-500 text-sm mt-1">{errors.lastName}</p>
                  )}
                </div>
              </div>

              <div>
                <label htmlFor="email" className="text-sm text-muted-foreground mb-2 block">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  placeholder="email@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className={`bg-secondary border-border h-12 ${errors.email ? "border-red-500" : ""}`}
                />
                {errors.email && (
                  <p className="text-red-500 text-sm mt-1">{errors.email}</p>
                )}
              </div>

              <div>
                <label htmlFor="phone" className="text-sm text-muted-foreground mb-2 block">
                  Telefon raqam
                </label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+998 90 123 45 67"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className={`bg-secondary border-border h-12 ${errors.phone ? "border-red-500" : ""}`}
                />
                {errors.phone && (
                  <p className="text-red-500 text-sm mt-1">{errors.phone}</p>
                )}
              </div>

              <div>
                <label htmlFor="password" className="text-sm text-muted-foreground mb-2 block">
                  Parol
                </label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Kamida 8 ta belgi"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className={`bg-secondary border-border h-12 pr-12 ${errors.password ? "border-red-500" : ""}`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
                {errors.password && (
                  <p className="text-red-500 text-sm mt-1">{errors.password}</p>
                )}
              </div>

              <div className="flex items-start gap-2">
                <Checkbox 
                  id="terms" 
                  className="mt-1" 
                  checked={formData.terms}
                  onCheckedChange={(checked) => setFormData({ ...formData, terms: checked as boolean })}
                />
                <div>
                  <label htmlFor="terms" className="text-sm text-muted-foreground cursor-pointer">
                    <Link href="#" className="text-primary hover:underline">
                      Foydalanish shartlari
                    </Link>{" "}
                    va{" "}
                    <Link href="#" className="text-primary hover:underline">
                      Maxfiylik siyosati
                    </Link>
                    ga roziman
                  </label>
                  {errors.terms && (
                    <p className="text-red-500 text-sm mt-1">{errors.terms}</p>
                  )}
                </div>
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground text-base font-semibold"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                    Ro&apos;yxatdan o&apos;tish...
                  </>
                ) : (
                  "Ro'yxatdan o'tish"
                )}
              </Button>
            </form>

            <p className="mt-6 text-center text-sm text-muted-foreground">
              Hisobingiz bormi?{" "}
              <Link href="/login" className="text-primary hover:underline font-medium">
                Kirish
              </Link>
            </p>
          </div>
        </div>
      </div>

      {/* Right Side - Features */}
      <div className="hidden lg:flex w-1/2 relative items-center justify-center">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1920&h=1080&fit=crop')] bg-cover bg-center" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-background/40" />

        <div className="relative z-10 p-12 max-w-lg">
          <h2 className="text-4xl font-bold text-foreground mb-6 text-balance">
            O&apos;zbekistondagi eng yaxshi kino platformasi
          </h2>
          <p className="text-lg text-muted-foreground mb-8 text-pretty">
            KinoFlix bilan eng sara filmlar va seriallarni HD sifatda tomosha qiling.
          </p>

          <ul className="space-y-4">
            {features.map((feature, index) => (
              <li key={index} className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                  <Check className="h-4 w-4 text-primary" />
                </div>
                <span className="text-foreground">{feature}</span>
              </li>
            ))}
          </ul>

          <div className="mt-12 glass rounded-xl p-6">
            <div className="flex items-center gap-4">
              <div className="flex -space-x-3">
                {[1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className="w-10 h-10 rounded-full bg-primary/30 border-2 border-background flex items-center justify-center text-sm font-medium text-foreground"
                  >
                    {String.fromCharCode(64 + i)}
                  </div>
                ))}
              </div>
              <div>
                <div className="font-semibold text-foreground">50,000+ foydalanuvchi</div>
                <div className="text-sm text-muted-foreground">Bizga qo&apos;shiling</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
