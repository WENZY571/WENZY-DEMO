"use client"

import { use, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowLeft, Star, Clock, Calendar, Play, Plus, Share2, ThumbsUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { VideoPlayer } from "@/components/video-player"
import { MovieCard } from "@/components/movie-card"
import { getMovieById, allMovies } from "@/lib/movies"

export default function MoviePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const router = useRouter()
  const [isWatching, setIsWatching] = useState(false)
  
  const movie = getMovieById(parseInt(id))
  
  if (!movie) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Kino topilmadi</h1>
          <Link href="/">
            <Button>Bosh sahifaga qaytish</Button>
          </Link>
        </div>
      </div>
    )
  }

  // Get related movies (same genre, excluding current)
  const relatedMovies = allMovies
    .filter(m => m.genre === movie.genre && m.id !== movie.id)
    .slice(0, 6)

  return (
    <div className="min-h-screen">
      {/* Back Button */}
      <div className="fixed top-4 left-4 z-50">
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => router.back()}
          className="glass hover:bg-white/20"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
      </div>

      {isWatching ? (
        /* Video Player Mode */
        <div className="min-h-screen bg-black">
          <div className="container mx-auto px-4 py-4">
            <VideoPlayer 
              src={movie.videoUrl} 
              poster={movie.image}
              title={movie.title}
            />
            
            <div className="mt-6">
              <Button 
                variant="outline" 
                onClick={() => setIsWatching(false)}
                className="glass"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Orqaga qaytish
              </Button>
            </div>
          </div>
        </div>
      ) : (
        /* Movie Details Mode */
        <>
          {/* Hero Section with Movie Backdrop */}
          <div className="relative h-[70vh] min-h-[500px]">
            <Image
              src={movie.image}
              alt={movie.title}
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-r from-background via-background/40 to-transparent" />
            
            {/* Movie Info Overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-8 md:p-16">
              <div className="container mx-auto">
                <div className="max-w-2xl">
                  {/* Genre Badge */}
                  <span className="inline-block px-3 py-1 rounded-full text-sm font-medium bg-primary/20 text-primary border border-primary/30 mb-4">
                    {movie.genre}
                  </span>
                  
                  <h1 className="text-4xl md:text-6xl font-bold mb-4 text-balance">
                    {movie.title}
                  </h1>
                  
                  {/* Movie Meta */}
                  <div className="flex flex-wrap items-center gap-4 text-muted-foreground mb-6">
                    <span className="flex items-center gap-1">
                      <Star className="h-5 w-5 fill-yellow-500 text-yellow-500" />
                      <span className="font-semibold text-foreground">{movie.rating}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {movie.year}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {movie.duration}
                    </span>
                  </div>
                  
                  <p className="text-lg text-muted-foreground mb-8 text-pretty">
                    {movie.description}
                  </p>
                  
                  {/* Action Buttons */}
                  <div className="flex flex-wrap items-center gap-4">
                    <Button 
                      size="lg" 
                      className="bg-primary hover:bg-primary/90 text-primary-foreground"
                      onClick={() => setIsWatching(true)}
                    >
                      <Play className="h-5 w-5 mr-2 fill-current" />
                      Ko&apos;rishni boshlash
                    </Button>
                    <Button size="lg" variant="secondary" className="glass">
                      <Plus className="h-5 w-5 mr-2" />
                      Ro&apos;yxatga qo&apos;shish
                    </Button>
                    <Button size="icon" variant="secondary" className="glass">
                      <ThumbsUp className="h-5 w-5" />
                    </Button>
                    <Button size="icon" variant="secondary" className="glass">
                      <Share2 className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Related Movies Section */}
          {relatedMovies.length > 0 && (
            <section className="py-12 px-4 md:px-8">
              <div className="container mx-auto">
                <h2 className="text-2xl font-bold mb-6">O&apos;xshash kinolar</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {relatedMovies.map((relatedMovie) => (
                    <Link key={relatedMovie.id} href={`/movie/${relatedMovie.id}`}>
                      <MovieCard movie={relatedMovie} />
                    </Link>
                  ))}
                </div>
              </div>
            </section>
          )}

          {/* Back to Home */}
          <section className="py-8 px-4">
            <div className="container mx-auto">
              <Link href="/">
                <Button variant="outline" className="glass">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Bosh sahifaga qaytish
                </Button>
              </Link>
            </div>
          </section>
        </>
      )}
    </div>
  )
}
