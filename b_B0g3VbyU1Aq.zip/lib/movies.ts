export interface Movie {
  id: number
  title: string
  year: number
  rating: number
  duration: string
  genre: string
  image: string
  description: string
  videoUrl: string
}

// Sample video URLs for demo purposes
const sampleVideos = [
  "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
  "https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
  "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
]

export const trendingMovies: Movie[] = [
  {
    id: 1,
    title: "Yo'lbars Jangchisi",
    year: 2024,
    rating: 8.5,
    duration: "2s 15d",
    genre: "Jangari",
    image: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&h=1200&fit=crop",
    description: "Qadimiy jang san'atini o'zlashtirishga qaror qilgan yigitning hayajonli sarguzashtlari. U o'z oilasini himoya qilish uchun eng kuchli jangchilar bilan kurashadi.",
    videoUrl: sampleVideos[0],
  },
  {
    id: 2,
    title: "Kecha va Kunduz",
    year: 2024,
    rating: 9.1,
    duration: "1s 58d",
    genre: "Drama",
    image: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&h=1200&fit=crop",
    description: "Ikki yosh sevishganlarning hayotini o'zgartirgan voqealar. Ular sevgini saqlash uchun barcha to'siqlarga qarshi turadi.",
    videoUrl: sampleVideos[1],
  },
  {
    id: 3,
    title: "Qorong'u Sirlar",
    year: 2024,
    rating: 8.8,
    duration: "2s 05d",
    genre: "Qo'rqinchli",
    image: "https://images.unsplash.com/photo-1509248961725-aec71f124cff?w=800&h=1200&fit=crop",
    description: "Qadimiy qo'rg'onda yashiringan qorong'u sirlar. Bir tergovchi haqiqatni topish uchun o'z hayotini xavf ostiga qo'yadi.",
    videoUrl: sampleVideos[2],
  },
  {
    id: 4,
    title: "Kulgili Oila",
    year: 2023,
    rating: 7.9,
    duration: "1s 45d",
    genre: "Komediya",
    image: "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=800&h=1200&fit=crop",
    description: "G'alati oilaning kundalik hayotidagi kulgili voqealar. Har bir epizod sizni kuldirishga kafolat beradi.",
    videoUrl: sampleVideos[3],
  },
]

export const actionMovies: Movie[] = [
  {
    id: 5,
    title: "Temir Yurak",
    year: 2024,
    rating: 8.7,
    duration: "2s 20d",
    genre: "Jangari",
    image: "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=800&h=1200&fit=crop",
    description: "Maxfiy agent dunyoni qutqarish uchun noma'lum kuchlar bilan jang qiladi.",
    videoUrl: sampleVideos[0],
  },
  {
    id: 6,
    title: "Oxirgi Jang",
    year: 2023,
    rating: 8.4,
    duration: "2s 10d",
    genre: "Jangari",
    image: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=800&h=1200&fit=crop",
    description: "Nafaqaga chiqqan harbiy qo'mondon o'z shahrini himoya qilish uchun qaytadi.",
    videoUrl: sampleVideos[1],
  },
  {
    id: 7,
    title: "Qora Pantera",
    year: 2024,
    rating: 9.0,
    duration: "2s 30d",
    genre: "Jangari",
    image: "https://images.unsplash.com/photo-1535016120720-40c646be5580?w=800&h=1200&fit=crop",
    description: "Kechqurun shahar ko'chalarida adolat uchun kurashuvchi niqobli qahramon.",
    videoUrl: sampleVideos[2],
  },
  {
    id: 8,
    title: "Tezkor Portlash",
    year: 2023,
    rating: 8.2,
    duration: "1s 55d",
    genre: "Jangari",
    image: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=800&h=1200&fit=crop",
    description: "Poyga mashinasida dunyoni kezib, jinoyatchilar bilan kurashuvchi haydovchi.",
    videoUrl: sampleVideos[3],
  },
  {
    id: 9,
    title: "Samurai Yo'li",
    year: 2024,
    rating: 8.6,
    duration: "2s 15d",
    genre: "Jangari",
    image: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=800&h=1200&fit=crop",
    description: "Qadimiy Yaponiyada o'z ustasining o'limini qasos olish uchun sayohat qiluvchi samurai.",
    videoUrl: sampleVideos[0],
  },
  {
    id: 10,
    title: "Olovli Harakatlar",
    year: 2023,
    rating: 7.8,
    duration: "1s 48d",
    genre: "Jangari",
    image: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&h=1200&fit=crop",
    description: "O't o'chiruvchilar jamoasi katta yong'in paytida qahramonlik ko'rsatadi.",
    videoUrl: sampleVideos[1],
  },
]

export const comedyMovies: Movie[] = [
  {
    id: 11,
    title: "Qo'shnilar Urushi",
    year: 2024,
    rating: 8.1,
    duration: "1s 40d",
    genre: "Komediya",
    image: "https://images.unsplash.com/photo-1616530940355-351fabd9524b?w=800&h=1200&fit=crop",
    description: "Ikki qo'shni o'rtasidagi kulgili to'qnashuvlar va yarashuv.",
    videoUrl: sampleVideos[3],
  },
  {
    id: 12,
    title: "To'y Sovg'asi",
    year: 2023,
    rating: 7.6,
    duration: "1s 35d",
    genre: "Komediya",
    image: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=800&h=1200&fit=crop",
    description: "To'y kuni yuz bergan kulgili voqealar to'plami.",
    videoUrl: sampleVideos[0],
  },
  {
    id: 13,
    title: "Yoshlik Xotirasi",
    year: 2024,
    rating: 8.3,
    duration: "1s 50d",
    genre: "Komediya",
    image: "https://images.unsplash.com/photo-1543584756-8f40af4bd8de?w=800&h=1200&fit=crop",
    description: "Maktab do'stlarining yillar o'tib qayta uchrashgandagi sarguzashtlari.",
    videoUrl: sampleVideos[1],
  },
  {
    id: 14,
    title: "Ofis Shovqini",
    year: 2023,
    rating: 7.9,
    duration: "1s 42d",
    genre: "Komediya",
    image: "https://images.unsplash.com/photo-1497215842964-222b430dc094?w=800&h=1200&fit=crop",
    description: "IT kompaniyasidagi xodimlarning kundalik kulgili hayoti.",
    videoUrl: sampleVideos[2],
  },
  {
    id: 15,
    title: "Sayohat Shovqini",
    year: 2024,
    rating: 8.0,
    duration: "1s 55d",
    genre: "Komediya",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=1200&fit=crop",
    description: "Bir guruh do'stlarning Yevropa bo'ylab sayohati davomidagi kulgili voqealar.",
    videoUrl: sampleVideos[3],
  },
  {
    id: 16,
    title: "Otam Qo'rig'i",
    year: 2023,
    rating: 7.7,
    duration: "1s 38d",
    genre: "Komediya",
    image: "https://images.unsplash.com/photo-1542204165-65bf26472b9b?w=800&h=1200&fit=crop",
    description: "Qattiq ota va erkin ruhli qizning o'zaro munosabatlari.",
    videoUrl: sampleVideos[0],
  },
]

export const horrorMovies: Movie[] = [
  {
    id: 17,
    title: "Qorong'u Uy",
    year: 2024,
    rating: 8.4,
    duration: "1s 58d",
    genre: "Qo'rqinchli",
    image: "https://images.unsplash.com/photo-1604975999044-188783d54fb3?w=800&h=1200&fit=crop",
    description: "Yangi uyga ko'chib kelgan oila qo'rqinchli hodisalarga duch keladi.",
    videoUrl: sampleVideos[2],
  },
  {
    id: 18,
    title: "La'nat",
    year: 2023,
    rating: 8.6,
    duration: "2s 05d",
    genre: "Qo'rqinchli",
    image: "https://images.unsplash.com/photo-1635805737707-575885ab0820?w=800&h=1200&fit=crop",
    description: "Qadimiy la'natdan qutulish uchun kurashayotgan ayol.",
    videoUrl: sampleVideos[3],
  },
  {
    id: 19,
    title: "Tungi Mehmon",
    year: 2024,
    rating: 8.2,
    duration: "1s 45d",
    genre: "Qo'rqinchli",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=1200&fit=crop",
    description: "Har tunda keluvchi sirli mehmon haqidagi dahshatli hikoya.",
    videoUrl: sampleVideos[0],
  },
  {
    id: 20,
    title: "O'lik Shahar",
    year: 2023,
    rating: 7.9,
    duration: "2s 00d",
    genre: "Qo'rqinchli",
    image: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800&h=1200&fit=crop",
    description: "Tashlab ketilgan shaharda qolgan odamlarning yashash uchun kurashi.",
    videoUrl: sampleVideos[1],
  },
  {
    id: 21,
    title: "Qabr Siri",
    year: 2024,
    rating: 8.5,
    duration: "1s 52d",
    genre: "Qo'rqinchli",
    image: "https://images.unsplash.com/photo-1601513445506-2ab0d4fb4229?w=800&h=1200&fit=crop",
    description: "Qabriston yaqinida yashovchi oilaning dahshatli sirlari.",
    videoUrl: sampleVideos[2],
  },
  {
    id: 22,
    title: "So'nggi Nafas",
    year: 2023,
    rating: 8.0,
    duration: "1s 48d",
    genre: "Qo'rqinchli",
    image: "https://images.unsplash.com/photo-1597423498219-04418210827d?w=800&h=1200&fit=crop",
    description: "Kasalxonada yuz bergan g'ayritabiiy hodisalar.",
    videoUrl: sampleVideos[3],
  },
]

export const allMovies: Movie[] = [
  ...trendingMovies,
  ...actionMovies,
  ...comedyMovies,
  ...horrorMovies,
]

export function getMovieById(id: number): Movie | undefined {
  return allMovies.find(movie => movie.id === id)
}

export function searchMovies(query: string): Movie[] {
  const lowerQuery = query.toLowerCase()
  return allMovies.filter(movie => 
    movie.title.toLowerCase().includes(lowerQuery) ||
    movie.genre.toLowerCase().includes(lowerQuery) ||
    movie.description.toLowerCase().includes(lowerQuery)
  )
}
